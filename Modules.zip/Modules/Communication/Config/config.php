<?php

return [
    'name' => 'Communication'
];
